import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Moon, Sun } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

const Navigation: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { isDark, toggleTheme } = useTheme();
  const location = useLocation();

  const navigation = [
    { name: 'Home', href: '/' },
    { name: 'About', href: '/about' },
    { name: 'Contact', href: '/contact' },
    { name: 'Careers', href: '/careers' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed top-4 left-1/2 transform -translate-x-1/2 max-w-4xl w-full sm:w-[80%] z-50">
      <div className="bg-white/10 dark:bg-black/10 backdrop-blur-md rounded-full sm:rounded-3xl shadow-lg border border-white/20 dark:border-gray-800/20">
        <div className="px-6 sm:px-8">
          <div className="flex items-center justify-between h-14">
            {/* Logo */}
            <div className="flex-shrink-0">
              <Link 
                to="/" 
                className="flex items-center hover:opacity-80 transition-opacity"
              >
                <img 
                  src="/NAQCORP ONLY Transparent.png" 
                  alt="NAQCORP" 
                  className="h-24 w-auto"
                />
              </Link>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex flex-1 justify-center space-x-8 items-center">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`relative text-sm font-semibold transition-all duration-200 hover:text-orange-500 ${
                    isActive(item.href) 
                      ? 'text-orange-500' 
                      : 'text-gray-900 dark:text-gray-100'
                  }`}
                >
                  {item.name}
                  {isActive(item.href) && (
                    <div className="absolute -bottom-1 left-0 right-0 h-0.5 bg-orange-500 rounded-full" />
                  )}
                </Link>
              ))}
            </div>

            {/* Theme Toggle & Mobile Menu */}
            <div className="flex items-center space-x-3">
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg bg-gray-100/80 dark:bg-gray-800/80 hover:bg-orange-100 dark:hover:bg-orange-900/30 transition-all duration-200 hover:scale-105"
              >
                {isDark ? (
                  <Sun className="w-5 h-5 text-gray-900 dark:text-gray-100" />
                ) : (
                  <Moon className="w-5 h-5 text-gray-900 dark:text-gray-100" />
                )}
              </button>
              
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="lg:hidden p-2 rounded-lg bg-gray-100/80 dark:bg-gray-800/80 hover:bg-orange-100 dark:hover:bg-orange-900/30 transition-all duration-200"
              >
                {isMenuOpen ? (
                  <X className="w-5 h-5 text-gray-900 dark:text-gray-100" />
                ) : (
                  <Menu className="w-5 h-5 text-gray-900 dark:text-gray-100" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden bg-white/20 dark:bg-black/20 backdrop-blur-md w-[95%] mx-auto rounded-3xl mt-3 mb-3">
            <div className="pt-2 pb-4 space-y-1">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={() => setIsMenuOpen(false)}
                  className={`block pl-4 pr-4 py-3 text-base font-semibold rounded-2xl mx-2 transition-all duration-200 ${
                    isActive(item.href)
                      ? 'bg-orange-500/20 text-orange-500'
                      : 'text-gray-900 dark:text-gray-100 hover:bg-gray-100/20 dark:hover:bg-gray-800/20'
                  }`}
                >
                  {item.name}
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;