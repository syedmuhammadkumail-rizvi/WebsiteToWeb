import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Twitter, Linkedin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gradient-to-br from-orange-600 via-orange-500 to-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <h3 className="text-2xl font-bold tracking-tight">NAQCORP</h3>
            <p className="text-gray-200 leading-relaxed">
              Providing top-quality engineering and logistics solutions for aerospace and automotive industries.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-xl font-bold">Quick Links</h3>
            <div className="space-y-2">
              <Link to="/" className="block text-gray-200 hover:text-white hover:underline transition-colors">
                Home
              </Link>
              <Link to="/about" className="block text-gray-200 hover:text-white hover:underline transition-colors">
                About
              </Link>
              <Link to="/contact" className="block text-gray-200 hover:text-white hover:underline transition-colors">
                Contact
              </Link>
              <Link to="/technologies" className="block text-gray-200 hover:text-white hover:underline transition-colors">
                Technologies
              </Link>
            </div>
          </div>

          {/* Connect */}
          <div className="space-y-4">
            <h3 className="text-xl font-bold">Connect</h3>
            <div className="space-y-3">
              <a href="#" className="flex items-center space-x-3 text-gray-200 hover:text-white transition-colors group">
                <Facebook className="w-5 h-5 group-hover:scale-110 transition-transform" />
                <span>Facebook</span>
              </a>
              <a href="#" className="flex items-center space-x-3 text-gray-200 hover:text-white transition-colors group">
                <Twitter className="w-5 h-5 group-hover:scale-110 transition-transform" />
                <span>Twitter</span>
              </a>
              <a href="#" className="flex items-center space-x-3 text-gray-200 hover:text-white transition-colors group">
                <Linkedin className="w-5 h-5 group-hover:scale-110 transition-transform" />
                <span>LinkedIn</span>
              </a>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="text-xl font-bold">Head Office</h3>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 mt-0.5 flex-shrink-0" />
                <span className="text-gray-200">House no 81, Lane no 4, Harley Street, Rawalpindi</span>
              </div>
              <a href="tel:+923215857205" className="flex items-center space-x-3 text-gray-200 hover:text-white transition-colors">
                <Phone className="w-4 h-4" />
                <span>+92 321 585 7205</span>
              </a>
              <a href="mailto:info@naqcorp.com" className="flex items-center space-x-3 text-gray-200 hover:text-white transition-colors">
                <Mail className="w-4 h-4" />
                <span>info@naqcorp.com</span>
              </a>
            </div>
          </div>
        </div>

        <hr className="my-8 border-gray-300/30" />
        
        <div className="text-center text-gray-200">
          <p>&copy; 2025 NAQCORP. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;