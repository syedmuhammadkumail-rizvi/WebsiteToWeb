import React from 'react';
import { Mail } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="min-h-screen">
      {/* About Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-gray-50 via-white to-gray-100 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl md:text-5xl font-extrabold text-center mb-12 text-gray-900 dark:text-gray-100">
            About NAQCORP
          </h1>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* NAQCORP Technologies */}
            <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100 dark:border-gray-700">
              <h2 className="text-2xl font-bold mb-4 text-orange-600">NAQCORP Technologies</h2>
              <p className="text-base leading-relaxed mb-6 text-gray-600 dark:text-gray-300">
                NAQCORP Technologies provides advanced consultancy services to the aerospace and automotive industries, offering world-class expertise in computational design, simulation, and engineering analysis. With a team of specialized engineers and decades of domain knowledge, the company helps clients solve complex technical challenges and meet rigorous industry standards.
              </p>
              
              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-gray-100">Core Services</h3>
                <ul className="space-y-2 text-gray-600 dark:text-gray-300">
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mr-3"></div>
                    CFD Simulations
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mr-3"></div>
                    Stress Analysis
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mr-3"></div>
                    Flight Dynamics
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mr-3"></div>
                    Aeroelasticity
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mr-3"></div>
                    Thermal Analysis
                  </li>
                </ul>
              </div>
              
              <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-600">
                <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-gray-100">Leadership</h3>
                <div className="flex items-start space-x-4">
                  <div className="w-24 h-24 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center text-white font-bold text-2xl flex-shrink-0">
                    ST
                  </div>
                  <div className="flex-1">
                    <h4 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Syed Tauqeer ul Islam Rizvi</h4>
                    <p className="text-sm font-medium text-orange-600 mb-2">CEO, NAQCORP Technologies</p>
                    <a 
                      href="mailto:tauqeer@naqcorp.com" 
                      className="inline-flex items-center text-sm text-orange-600 hover:text-orange-700 transition-colors"
                    >
                      <Mail className="w-4 h-4 mr-1" />
                      tauqeer@naqcorp.com
                    </a>
                    <p className="mt-3 text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
                      Dr. Syed Tauqeer ul Islam Rizvi is a veteran aerospace engineer with over 30 years of experience in flight vehicle design, aeroelasticity, and computational fluid dynamics. He holds a Ph.D. in Flight Vehicle Design from Beihang University (2010–2013), an ME in Aerospace Engineering from Iowa State University (2001–2002), and a Bachelor's in Aeronautical Engineering from the College of Aeronautical Engineering (1990–1993).
                    </p>
                    <p className="mt-2 text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
                      In recognition of his outstanding contributions to aerospace engineering, he received the Pride of Performance Award from the President of Pakistan in March 2008. At NAQCORP Technologies, he leads the development of high-impact engineering solutions for cutting-edge industries.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* NAQCORP Engineering Solutions */}
            <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100 dark:border-gray-700">
              <h2 className="text-2xl font-bold mb-4 text-orange-600">NAQCORP Engineering Solutions</h2>
              <p className="text-base leading-relaxed mb-6 text-gray-600 dark:text-gray-300">
                NAQCORP Engineering Solutions is a logistics and trade services firm focused on import/export, supply chain optimization, and customs clearance. Known for its unmatched ability to handle complex and sensitive shipments, the company has served global clients such as Flash Global and Palo Alto Networks, providing IOR/EOR, warehousing, and freight forwarding services with a reputation for reliability.
              </p>
              
              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-gray-100">Core Services</h3>
                <ul className="space-y-2 text-gray-600 dark:text-gray-300">
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mr-3"></div>
                    Import/Export
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mr-3"></div>
                    IOR/EOR Services
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mr-3"></div>
                    Freight Forwarding
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mr-3"></div>
                    Customs Clearance
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mr-3"></div>
                    Warehousing
                  </li>
                  <li className="flex items-center">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mr-3"></div>
                    Supply Chain Optimization
                  </li>
                </ul>
              </div>
              
              <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-600">
                <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-gray-100">Leadership</h3>
                <div className="flex items-start space-x-4">
                  <div className="w-24 h-24 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center text-white font-bold text-2xl flex-shrink-0">
                    ST
                  </div>
                  <div className="flex-1">
                    <h4 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Syed Tauseef ul Islam Rizvi</h4>
                    <p className="text-sm font-medium text-orange-600 mb-2">Director, NAQCORP Engineering Solutions</p>
                    <a 
                      href="mailto:tauseef@naqcorp.com" 
                      className="inline-flex items-center text-sm text-orange-600 hover:text-orange-700 transition-colors"
                    >
                      <Mail className="w-4 h-4 mr-1" />
                      tauseef@naqcorp.com
                    </a>
                    <p className="mt-3 text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
                      Syed Tauseef ul Islam Rizvi brings over 13 years of banking experience, equipping him with exceptional insight into regulatory systems, financial compliance, and problem-solving in high-pressure trade scenarios. His expertise makes NAQCORP Engineering Solutions particularly effective at resolving stuck or sensitive shipments — even when others fail.
                    </p>
                    <p className="mt-2 text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
                      Under his leadership, the company is now focused on growing locally and building capacity to register in Dubai, allowing it to reintroduce its paused IOR/EOR services in a globally stable and compliant environment.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;