import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Upload, MapPin, Clock, Users, CheckCircle, AlertCircle } from 'lucide-react';

interface JobDetails {
  id: string;
  title: string;
  department: string;
  location: string;
  type: string;
  experience: string;
  description: string;
  requirements: string[];
  responsibilities: string[];
}

const JobApplication: React.FC = () => {
  const { jobId } = useParams<{ jobId: string }>();
  const [job, setJob] = useState<JobDetails | null>(null);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    coverLetter: '',
    experience: '',
    education: '',
    skills: '',
    availability: '',
    salary: '',
    references: ''
  });
  const [cvFile, setCvFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const jobs: { [key: string]: JobDetails } = {
    'aerospace-engineer': {
      id: 'aerospace-engineer',
      title: 'Senior Aerospace Engineer',
      department: 'NAQCORP Technologies',
      location: 'Rawalpindi, Pakistan',
      type: 'Full-time',
      experience: '5+ years',
      description: 'Lead computational fluid dynamics projects and flight vehicle design for aerospace clients. Work with cutting-edge simulation tools and collaborate with international teams on innovative aerospace solutions.',
      requirements: [
        'Master\'s degree in Aerospace Engineering or related field',
        '5+ years experience in CFD simulations',
        'Proficiency in ANSYS, MATLAB, or similar tools',
        'Experience with flight dynamics and aeroelasticity',
        'Strong analytical and problem-solving skills',
        'Excellent communication and teamwork abilities'
      ],
      responsibilities: [
        'Conduct advanced CFD simulations and analysis',
        'Lead flight vehicle design projects',
        'Collaborate with international aerospace clients',
        'Mentor junior engineers and technical staff',
        'Prepare technical reports and presentations',
        'Stay updated with latest aerospace technologies'
      ]
    },
    'logistics-coordinator': {
      id: 'logistics-coordinator',
      title: 'Logistics Coordinator',
      department: 'NAQCORP Engineering Solutions',
      location: 'Rawalpindi, Pakistan',
      type: 'Full-time',
      experience: '3+ years',
      description: 'Manage import/export operations and coordinate with global clients for supply chain optimization. Handle complex shipments and ensure compliance with international trade regulations.',
      requirements: [
        'Bachelor\'s degree in Supply Chain Management or related field',
        '3+ years experience in logistics and trade',
        'Knowledge of customs regulations and IOR/EOR processes',
        'Strong communication and problem-solving skills',
        'Experience with international shipping and documentation',
        'Proficiency in logistics software and systems'
      ],
      responsibilities: [
        'Coordinate import/export operations',
        'Manage customs clearance processes',
        'Optimize supply chain operations for clients',
        'Handle sensitive and complex shipments',
        'Maintain relationships with shipping partners',
        'Ensure compliance with trade regulations'
      ]
    },
    'simulation-specialist': {
      id: 'simulation-specialist',
      title: 'Simulation Specialist',
      department: 'NAQCORP Technologies',
      location: 'Rawalpindi, Pakistan',
      type: 'Full-time',
      experience: '2+ years',
      description: 'Perform stress analysis and thermal simulations for automotive and aerospace applications. Work with industry-standard simulation tools to solve complex engineering challenges.',
      requirements: [
        'Bachelor\'s degree in Mechanical or Aerospace Engineering',
        '2+ years experience in FEA and simulation',
        'Proficiency in Abaqus, CATIA, or MSC Nastran',
        'Understanding of structural mechanics and thermal analysis',
        'Experience with CAD software',
        'Strong attention to detail and accuracy'
      ],
      responsibilities: [
        'Perform stress analysis and structural simulations',
        'Conduct thermal analysis for various applications',
        'Prepare technical reports and documentation',
        'Support project teams with simulation expertise',
        'Validate simulation results with experimental data',
        'Optimize designs based on simulation findings'
      ]
    },
    'trade-compliance-officer': {
      id: 'trade-compliance-officer',
      title: 'Trade Compliance Officer',
      department: 'NAQCORP Engineering Solutions',
      location: 'Rawalpindi, Pakistan',
      type: 'Full-time',
      experience: '4+ years',
      description: 'Ensure compliance with international trade regulations and manage regulatory documentation. Work with customs authorities and maintain up-to-date knowledge of trade laws.',
      requirements: [
        'Bachelor\'s degree in International Business or related field',
        '4+ years experience in trade compliance',
        'Knowledge of international trade regulations',
        'Experience with regulatory documentation and processes',
        'Strong analytical and research skills',
        'Excellent written and verbal communication'
      ],
      responsibilities: [
        'Ensure compliance with trade regulations',
        'Manage regulatory documentation',
        'Coordinate with customs authorities',
        'Develop compliance procedures and policies',
        'Train staff on compliance requirements',
        'Monitor changes in trade regulations'
      ]
    }
  };

  useEffect(() => {
    if (jobId && jobs[jobId]) {
      setJob(jobs[jobId]);
    }
  }, [jobId]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Check file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert('File size must be less than 5MB');
        return;
      }
      // Check file type
      const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
      if (!allowedTypes.includes(file.type)) {
        alert('Please upload a PDF or Word document');
        return;
      }
      setCvFile(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Simulate form submission
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Create email content
      const emailSubject = `Job Application: ${job?.title} - ${formData.firstName} ${formData.lastName}`;
      const emailBody = `
Job Application Details:

Position: ${job?.title}
Department: ${job?.department}
Applicant: ${formData.firstName} ${formData.lastName}

Contact Information:
Email: ${formData.email}
Phone: ${formData.phone}
Address: ${formData.address}

Experience: ${formData.experience}
Education: ${formData.education}
Skills: ${formData.skills}
Availability: ${formData.availability}
Expected Salary: ${formData.salary}

Cover Letter:
${formData.coverLetter}

References:
${formData.references}

CV File: ${cvFile ? cvFile.name : 'Not attached'}
      `;
      
      // Create mailto link
      const mailtoLink = `mailto:info@naqcorp.com?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
      window.location.href = mailtoLink;
      
      setSubmitStatus('success');
    } catch (error) {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!job) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Job Not Found</h1>
          <Link to="/careers" className="text-orange-600 hover:text-orange-700">
            Back to Careers
          </Link>
        </div>
      </div>
    );
  }

  if (submitStatus === 'success') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="max-w-md w-full bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-8 text-center">
          <div className="w-16 h-16 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Application Submitted!</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            Your application for {job.title} has been submitted successfully. We'll review your application and get back to you soon.
          </p>
          <Link
            to="/careers"
            className="inline-flex items-center space-x-2 bg-gradient-to-r from-orange-600 to-orange-500 text-white font-semibold py-3 px-6 rounded-lg hover:from-orange-700 hover:to-orange-600 transition-all duration-200"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Careers</span>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link
            to="/careers"
            className="inline-flex items-center space-x-2 text-orange-600 hover:text-orange-700 transition-colors mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Careers</span>
          </Link>
          
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{job.title}</h1>
              <p className="text-orange-600 font-medium text-lg mt-1">{job.department}</p>
              
              <div className="flex items-center space-x-6 mt-4 text-sm text-gray-500 dark:text-gray-400">
                <div className="flex items-center">
                  <MapPin className="w-4 h-4 mr-1" />
                  {job.location}
                </div>
                <div className="flex items-center">
                  <Clock className="w-4 h-4 mr-1" />
                  {job.experience}
                </div>
                <div className="flex items-center">
                  <Users className="w-4 h-4 mr-1" />
                  {job.type}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Job Details */}
          <div className="lg:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 sticky top-8">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Job Details</h2>
              
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Description</h3>
                  <p className="text-gray-600 dark:text-gray-300 text-sm">{job.description}</p>
                </div>
                
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Requirements</h3>
                  <ul className="space-y-1">
                    {job.requirements.map((req, index) => (
                      <li key={index} className="text-gray-600 dark:text-gray-300 text-sm flex items-start">
                        <div className="w-1.5 h-1.5 bg-orange-500 rounded-full mt-2 mr-2 flex-shrink-0"></div>
                        {req}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Responsibilities</h3>
                  <ul className="space-y-1">
                    {job.responsibilities.map((resp, index) => (
                      <li key={index} className="text-gray-600 dark:text-gray-300 text-sm flex items-start">
                        <div className="w-1.5 h-1.5 bg-orange-500 rounded-full mt-2 mr-2 flex-shrink-0"></div>
                        {resp}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Application Form */}
          <div className="lg:col-span-2">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Apply for this Position</h2>
              
              {submitStatus === 'error' && (
                <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg flex items-center">
                  <AlertCircle className="w-5 h-5 text-red-600 mr-2" />
                  <span className="text-red-700 dark:text-red-400">There was an error submitting your application. Please try again.</span>
                </div>
              )}
              
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Personal Information */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      First Name *
                    </label>
                    <input
                      type="text"
                      id="firstName"
                      name="firstName"
                      required
                      value={formData.firstName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Last Name *
                    </label>
                    <input
                      type="text"
                      id="lastName"
                      name="lastName"
                      required
                      value={formData.lastName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      required
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="address" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Address
                  </label>
                  <input
                    type="text"
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>

                {/* CV Upload */}
                <div>
                  <label htmlFor="cv" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Upload CV/Resume * (PDF or Word, max 5MB)
                  </label>
                  <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center hover:border-orange-500 transition-colors">
                    <input
                      type="file"
                      id="cv"
                      accept=".pdf,.doc,.docx"
                      onChange={handleFileChange}
                      className="hidden"
                      required
                    />
                    <label htmlFor="cv" className="cursor-pointer">
                      <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600 dark:text-gray-300">
                        {cvFile ? cvFile.name : 'Click to upload your CV/Resume'}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                        PDF or Word document, max 5MB
                      </p>
                    </label>
                  </div>
                </div>

                {/* Professional Information */}
                <div>
                  <label htmlFor="experience" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Relevant Experience *
                  </label>
                  <textarea
                    id="experience"
                    name="experience"
                    required
                    rows={4}
                    value={formData.experience}
                    onChange={handleInputChange}
                    placeholder="Describe your relevant work experience..."
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>

                <div>
                  <label htmlFor="education" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Education *
                  </label>
                  <textarea
                    id="education"
                    name="education"
                    required
                    rows={3}
                    value={formData.education}
                    onChange={handleInputChange}
                    placeholder="List your educational qualifications..."
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>

                <div>
                  <label htmlFor="skills" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Key Skills *
                  </label>
                  <textarea
                    id="skills"
                    name="skills"
                    required
                    rows={3}
                    value={formData.skills}
                    onChange={handleInputChange}
                    placeholder="List your key skills and technical competencies..."
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="availability" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Availability
                    </label>
                    <select
                      id="availability"
                      name="availability"
                      value={formData.availability}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    >
                      <option value="">Select availability</option>
                      <option value="immediate">Immediate</option>
                      <option value="2-weeks">2 weeks notice</option>
                      <option value="1-month">1 month notice</option>
                      <option value="2-months">2 months notice</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                  
                  <div>
                    <label htmlFor="salary" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Expected Salary (PKR)
                    </label>
                    <input
                      type="text"
                      id="salary"
                      name="salary"
                      value={formData.salary}
                      onChange={handleInputChange}
                      placeholder="e.g., 80,000 - 100,000"
                      className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="coverLetter" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Cover Letter *
                  </label>
                  <textarea
                    id="coverLetter"
                    name="coverLetter"
                    required
                    rows={6}
                    value={formData.coverLetter}
                    onChange={handleInputChange}
                    placeholder="Tell us why you're interested in this position and why you'd be a great fit..."
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>

                <div>
                  <label htmlFor="references" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    References
                  </label>
                  <textarea
                    id="references"
                    name="references"
                    rows={3}
                    value={formData.references}
                    onChange={handleInputChange}
                    placeholder="Provide contact information for professional references (optional)..."
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  />
                </div>

                <div className="pt-6">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-orange-600 to-orange-500 text-white font-semibold py-4 px-6 rounded-lg hover:from-orange-700 hover:to-orange-600 transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                  >
                    {isSubmitting ? 'Submitting Application...' : 'Submit Application'}
                  </button>
                  
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-4 text-center">
                    By submitting this application, you agree to our privacy policy and terms of service.
                  </p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobApplication;