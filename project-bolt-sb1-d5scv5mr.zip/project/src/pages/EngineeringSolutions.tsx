import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle } from 'lucide-react';

const EngineeringSolutions: React.FC = () => {
  const services = [
    {
      title: "Import/Export Services",
      description: "Streamlined global trade solutions for efficient import and export operations.",
      icon: "🌐"
    },
    {
      title: "IOR/EOR Services", 
      description: "Expert Importer/Exporter of Record services for compliance and ease.",
      icon: "📋"
    },
    {
      title: "Freight Services",
      description: "Reliable freight forwarding for optimized logistics and delivery.",
      icon: "🚛"
    },
    {
      title: "Custom Clearance",
      description: "Fast and compliant customs clearance for seamless operations.",
      icon: "✅"
    }
  ];

  const clients = [
    { name: "Flash", logo: "https://images.pexels.com/photos/6802049/pexels-photo-6802049.jpeg?auto=compress&cs=tinysrgb&w=400" },
    { name: "Palo Alto", logo: "https://images.pexels.com/photos/6802042/pexels-photo-6802042.jpeg?auto=compress&cs=tinysrgb&w=400" }
  ];

  const projects = [
    {
      title: "Stuck Shipments Cleared",
      description: "Successfully cleared stuck shipments through expert customs and logistics coordination.",
      percentage: 100
    },
    {
      title: "Freight Optimization", 
      description: "Optimized freight operations for efficient global logistics.",
      percentage: 95
    },
    {
      title: "Customs Compliance",
      description: "Ensured compliance with international customs regulations.",
      percentage: 90
    }
  ];

  const [currentSlide, setCurrentSlide] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % clients.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [clients.length]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.5 }
    );

    const progressSection = document.getElementById('projects-completed');
    if (progressSection) {
      observer.observe(progressSection);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 bg-gradient-to-br from-orange-500 via-orange-600 to-red-600 overflow-hidden">
        <div className="absolute inset-0 bg-black/10" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-6">
            <h2 className="text-2xl md:text-3xl font-semibold text-white/90">
              ENGINEERING SOLUTIONS
            </h2>
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-white leading-tight">
              EXPERTISE IN <span className="text-orange-200">LOGISTICS & SUPPLY CHAIN</span>
            </h1>
            <p className="text-lg md:text-xl text-white/90 max-w-4xl mx-auto">
              NAQCORP's Engineering Solutions division specializes in import/export, IOR/EOR, freight services, and custom clearance, delivering seamless logistics and supply chain solutions.
            </p>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Our Services</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Comprehensive logistics and supply chain solutions
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <div 
                key={index}
                className="group bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100 dark:border-gray-700"
              >
                <div className="text-4xl mb-4">{service.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3 group-hover:text-orange-600 transition-colors">
                  {service.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed text-sm">
                  {service.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Who We Have Worked With Section */}
      <section className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Who We Have Worked With</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Trusted by leading companies worldwide
            </p>
          </div>
          
          <div className="relative max-w-2xl mx-auto">
            <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-lg p-8 border border-gray-100 dark:border-gray-700">
              <div className="relative h-32 flex items-center justify-center overflow-hidden">
                {clients.map((client, index) => (
                  <div
                    key={index}
                    className={`absolute inset-0 flex items-center justify-center transition-opacity duration-1000 ${
                      index === currentSlide ? 'opacity-100' : 'opacity-0'
                    }`}
                  >
                    <img
                      src={client.logo}
                      alt={client.name}
                      className="max-h-20 max-w-full object-contain filter hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                ))}
              </div>
              
              <div className="flex justify-center space-x-2 mt-6">
                {clients.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-3 h-3 rounded-full transition-colors ${
                      index === currentSlide ? 'bg-orange-600' : 'bg-gray-300 dark:bg-gray-600'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Completed Section */}
      <section id="projects-completed" className="py-20 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Projects Completed</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Our track record of successful project delivery
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {projects.map((project, index) => (
              <div key={index} className="text-center">
                <div className="relative w-32 h-32 mx-auto mb-6">
                  <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 120 120">
                    <circle
                      cx="60"
                      cy="60"
                      r="50"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="8"
                      className="text-gray-200 dark:text-gray-700"
                    />
                    <circle
                      cx="60"
                      cy="60"
                      r="50"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="8"
                      strokeLinecap="round"
                      className="text-orange-600"
                      strokeDasharray={314.16}
                      strokeDashoffset={isVisible ? 314.16 - (314.16 * project.percentage) / 100 : 314.16}
                      style={{
                        transition: 'stroke-dashoffset 2s ease-in-out'
                      }}
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-2xl font-bold text-gray-900 dark:text-white">
                      {isVisible ? project.percentage : 0}%
                    </span>
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{project.title}</h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed max-w-sm mx-auto">
                  {project.description}
                </p>
              </div>
            ))}
          </div>
          
          <div className="text-center">
            <p className="text-lg text-gray-600 dark:text-gray-300 mb-6">
              Want to learn more about our successful projects? Get in touch!
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center space-x-2 bg-gradient-to-r from-orange-600 to-orange-500 text-white font-semibold py-3 px-6 rounded-lg hover:from-orange-700 hover:to-orange-600 transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <span>Contact Us</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default EngineeringSolutions;