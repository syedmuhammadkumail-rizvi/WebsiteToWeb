import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Clock, Users, ArrowRight, Briefcase } from 'lucide-react';

const Careers: React.FC = () => {
  const jobs = [
    {
      id: 'aerospace-engineer',
      title: 'Senior Aerospace Engineer',
      department: 'NAQCORP Technologies',
      location: 'Rawalpindi, Pakistan',
      type: 'Full-time',
      experience: '5+ years',
      description: 'Lead computational fluid dynamics projects and flight vehicle design for aerospace clients.',
      requirements: [
        'Master\'s degree in Aerospace Engineering or related field',
        '5+ years experience in CFD simulations',
        'Proficiency in ANSYS, MATLAB, or similar tools',
        'Experience with flight dynamics and aeroelasticity'
      ],
      responsibilities: [
        'Conduct advanced CFD simulations and analysis',
        'Lead flight vehicle design projects',
        'Collaborate with international aerospace clients',
        'Mentor junior engineers and technical staff'
      ]
    },
    {
      id: 'logistics-coordinator',
      title: 'Logistics Coordinator',
      department: 'NAQCORP Engineering Solutions',
      location: 'Rawalpindi, Pakistan',
      type: 'Full-time',
      experience: '3+ years',
      description: 'Manage import/export operations and coordinate with global clients for supply chain optimization.',
      requirements: [
        'Bachelor\'s degree in Supply Chain Management or related field',
        '3+ years experience in logistics and trade',
        'Knowledge of customs regulations and IOR/EOR processes',
        'Strong communication and problem-solving skills'
      ],
      responsibilities: [
        'Coordinate import/export operations',
        'Manage customs clearance processes',
        'Optimize supply chain operations for clients',
        'Handle sensitive and complex shipments'
      ]
    },
    {
      id: 'simulation-specialist',
      title: 'Simulation Specialist',
      department: 'NAQCORP Technologies',
      location: 'Rawalpindi, Pakistan',
      type: 'Full-time',
      experience: '2+ years',
      description: 'Perform stress analysis and thermal simulations for automotive and aerospace applications.',
      requirements: [
        'Bachelor\'s degree in Mechanical or Aerospace Engineering',
        '2+ years experience in FEA and simulation',
        'Proficiency in Abaqus, CATIA, or MSC Nastran',
        'Understanding of structural mechanics and thermal analysis'
      ],
      responsibilities: [
        'Perform stress analysis and structural simulations',
        'Conduct thermal analysis for various applications',
        'Prepare technical reports and documentation',
        'Support project teams with simulation expertise'
      ]
    },
    {
      id: 'trade-compliance-officer',
      title: 'Trade Compliance Officer',
      department: 'NAQCORP Engineering Solutions',
      location: 'Rawalpindi, Pakistan',
      type: 'Full-time',
      experience: '4+ years',
      description: 'Ensure compliance with international trade regulations and manage regulatory documentation.',
      requirements: [
        'Bachelor\'s degree in International Business or related field',
        '4+ years experience in trade compliance',
        'Knowledge of international trade regulations',
        'Experience with regulatory documentation and processes'
      ],
      responsibilities: [
        'Ensure compliance with trade regulations',
        'Manage regulatory documentation',
        'Coordinate with customs authorities',
        'Develop compliance procedures and policies'
      ]
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-orange-500 via-orange-600 to-red-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-6">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-white leading-tight">
              Join Our <span className="text-orange-200">Team</span>
            </h1>
            <p className="text-lg md:text-xl text-white/90 max-w-3xl mx-auto">
              Build your career with NAQCORP and be part of innovative engineering solutions and cutting-edge technology projects that shape the future of aerospace and logistics industries.
            </p>
          </div>
        </div>
      </section>

      {/* Why Work With Us */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Why Work With Us</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Join a team that values innovation, excellence, and professional growth
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center group">
              <div className="w-16 h-16 bg-orange-100 dark:bg-orange-900/20 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <Briefcase className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Cutting-Edge Projects</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Work on innovative aerospace and logistics projects with global impact and industry-leading clients.
              </p>
            </div>
            
            <div className="text-center group">
              <div className="w-16 h-16 bg-orange-100 dark:bg-orange-900/20 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <Users className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Expert Team</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Collaborate with experienced professionals and learn from industry veterans with decades of expertise.
              </p>
            </div>
            
            <div className="text-center group">
              <div className="w-16 h-16 bg-orange-100 dark:bg-orange-900/20 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <ArrowRight className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Career Growth</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Advance your career with opportunities for professional development and leadership roles.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Open Positions */}
      <section className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Open Positions</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Explore exciting career opportunities across our divisions
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {jobs.map((job) => (
              <div key={job.id} className="bg-white dark:bg-gray-900 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100 dark:border-gray-700">
                <div className="p-8">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{job.title}</h3>
                      <p className="text-orange-600 font-medium">{job.department}</p>
                    </div>
                    <span className="bg-orange-100 dark:bg-orange-900/20 text-orange-600 px-3 py-1 rounded-full text-sm font-medium">
                      {job.type}
                    </span>
                  </div>
                  
                  <p className="text-gray-600 dark:text-gray-300 mb-6">{job.description}</p>
                  
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                      <MapPin className="w-4 h-4 mr-2" />
                      {job.location}
                    </div>
                    <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                      <Clock className="w-4 h-4 mr-2" />
                      {job.experience}
                    </div>
                  </div>
                  
                  <Link
                    to={`/careers/apply/${job.id}`}
                    className="inline-flex items-center space-x-2 bg-gradient-to-r from-orange-600 to-orange-500 text-white font-semibold py-3 px-6 rounded-lg hover:from-orange-700 hover:to-orange-600 transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
                  >
                    <span>Apply Now</span>
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact for More Info */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Don't See the Right Position?</h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            We're always looking for talented individuals to join our team. Send us your resume and we'll keep you in mind for future opportunities.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center space-x-2 bg-gradient-to-r from-orange-600 to-orange-500 text-white font-semibold py-3 px-8 rounded-lg hover:from-orange-700 hover:to-orange-600 transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            <span>Contact Us</span>
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Careers;