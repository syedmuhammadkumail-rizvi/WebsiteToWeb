import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle } from 'lucide-react';

const Technologies: React.FC = () => {
  const services = [
    {
      title: "CFD Simulations",
      description: "Using CFD simulations we optimize performance and fluid dynamics in real-world applications.",
      image: "https://images.pexels.com/photos/5668858/pexels-photo-5668858.jpeg?auto=compress&cs=tinysrgb&w=800"
    },
    {
      title: "Stress Analysis", 
      description: "We offer comprehensive solutions for the design and analysis of mechanical/aerospace structures, ensuring the structural integrity of critical engineering components & assemblies.",
      image: "https://images.pexels.com/photos/5668772/pexels-photo-5668772.jpeg?auto=compress&cs=tinysrgb&w=800"
    },
    {
      title: "Flight Dynamics & Control",
      description: "Our services extend to the intricate fields of flight dynamics & control. We offer state of the art 6 DOF Simulations with flight controls modelling.",
      image: "https://images.pexels.com/photos/2526935/pexels-photo-2526935.jpeg?auto=compress&cs=tinysrgb&w=800"
    },
    {
      title: "Aeroelasticity",
      description: "Our experts specialize carrying out multi-physics simulation comprising of aerodynamic loads and structural response.",
      image: "https://images.pexels.com/photos/5668792/pexels-photo-5668792.jpeg?auto=compress&cs=tinysrgb&w=800"
    },
    {
      title: "Thermal Analysis",
      description: "Leveraging sophisticated tools and simulations, we conduct in-depth thermal analysis to understand heat distribution and devise efficient cooling strategies for your system.",
      image: "https://images.pexels.com/photos/5668856/pexels-photo-5668856.jpeg?auto=compress&cs=tinysrgb&w=800"
    },
    {
      title: "Aerodynamics Performance",
      description: "With our custom performance codes we utilize aerodynamic data for computation of platform performance charts.",
      image: "https://images.pexels.com/photos/2526105/pexels-photo-2526105.jpeg?auto=compress&cs=tinysrgb&w=800"
    }
  ];

  const keyFeatures = [
    "CFD Simulations for performance optimization",
    "Comprehensive stress analysis and structural integrity",
    "6 DOF Simulations with flight controls modelling"
  ];

  const tools = [
    {
      name: "MATLAB",
      logo: "https://upload.wikimedia.org/wikipedia/commons/2/21/Matlab_Logo.png",
      description: "Advanced mathematical computing and simulation platform"
    },
    {
      name: "CATIA",
      logo: "https://logos-world.net/wp-content/uploads/2022/02/Catia-Logo.png",
      description: "Comprehensive design and engineering capabilities"
    },
    {
      name: "Abaqus", 
      logo: "https://logos-world.net/wp-content/uploads/2022/02/Abaqus-Logo.png",
      description: "Realistic and reliable simulations for complex problems"
    },
    {
      name: "Ansys",
      logo: "https://upload.wikimedia.org/wikipedia/commons/e/e5/ANSYS_logo.png",
      description: "Advanced simulations and engineering design optimization"
    },
    {
      name: "MSC Software",
      logo: "https://logos-world.net/wp-content/uploads/2022/02/MSC-Software-Logo.png", 
      description: "High-fidelity finite element analysis and simulation"
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 bg-gradient-to-br from-orange-500 via-orange-600 to-red-600 overflow-hidden">
        <div className="absolute inset-0 bg-black/10" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-6">
            <h2 className="text-2xl md:text-3xl font-semibold text-white/90">
              NAQCORP TECHNOLOGIES
            </h2>
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-white leading-tight">
              PROFICIENCY IN <span className="text-orange-200">INDUSTRY-STANDARD</span> TOOLS
            </h1>
            <p className="text-lg md:text-xl text-white/90 max-w-4xl mx-auto">
              Proficiency in industry-standard tools such as Ansys, Abaqus, MSC Nastran NX, Matlab, and CATIA indicates a strong skill set in the field of engineering and simulation.
            </p>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Our Services</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Advanced engineering solutions powered by cutting-edge technology
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div 
                key={index}
                className="group bg-white dark:bg-gray-800 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100 dark:border-gray-700 overflow-hidden"
              >
                <div className="aspect-w-16 aspect-h-9 overflow-hidden">
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3 group-hover:text-orange-600 transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                    {service.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Key Features Section */}
      <section className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Key Features</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              What sets our technology solutions apart
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {keyFeatures.map((feature, index) => (
              <div key={index} className="bg-white dark:bg-gray-900 p-8 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-orange-600 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-white" />
                  </div>
                  <p className="text-lg text-gray-900 dark:text-white font-medium leading-relaxed">
                    {feature}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Tools Section */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Our Tools</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Industry-leading software and platforms we use
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-12">
            {tools.map((tool, index) => (
              <div 
                key={index}
                className="group bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100 dark:border-gray-700 text-center"
              >
                <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center p-2 group-hover:scale-110 transition-transform">
                  <img 
                    src={tool.logo} 
                    alt={`${tool.name} Logo`}
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">{tool.name}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300">{tool.description}</p>
              </div>
            ))}
          </div>
          
          <div className="text-center">
            <p className="text-lg text-gray-600 dark:text-gray-300 mb-6">
              Looking for more? Feel free to let us know.
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center space-x-2 bg-gradient-to-r from-orange-600 to-orange-500 text-white font-semibold py-3 px-6 rounded-lg hover:from-orange-700 hover:to-orange-600 transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <span>Contact Us</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Technologies;