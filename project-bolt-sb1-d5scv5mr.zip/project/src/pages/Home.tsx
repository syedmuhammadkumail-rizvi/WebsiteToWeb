import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Cog, 
  Globe, 
  Warehouse, 
  Link as LinkIcon, 
  PlusCircle, 
  Zap,
  BarChart3,
  Code,
  Settings,
  Phone,
  Mail,
  ArrowRight,
  CheckCircle,
  Lightbulb
} from 'lucide-react';

const Home: React.FC = () => {
  const services = [
    {
      icon: <Cog className="w-12 h-12" />,
      title: "Engineering Consultancy",
      description: "Our team of experienced engineers and consultants provides expert advice and innovative solutions to various engineering challenges, ensuring project success and client satisfaction."
    },
    {
      icon: <Globe className="w-12 h-12" />,
      title: "IOR/EOR Services",
      description: "Our Import and Export Services ensure smooth and efficient operations, handling all customs compliance and paperwork, allowing you to focus on your core business."
    },
    {
      icon: <Warehouse className="w-12 h-12" />,
      title: "Warehousing",
      description: "With our state-of-the-art warehousing facilities, we provide secure and efficient storage solutions tailored to your specific needs, ensuring optimal inventory management."
    },
    {
      icon: <LinkIcon className="w-12 h-12" />,
      title: "Provision of Automotive and Aircraft Spares",
      description: "We offer a comprehensive range of genuine spare parts for the automotive and aircraft industries, guaranteeing reliability and performance for your vehicles and aircraft."
    },
    {
      icon: <PlusCircle className="w-12 h-12" />,
      title: "Custom Solutions",
      description: "Custom solutions in engineering consultancy often require a multidisciplinary approach, drawing on expertise in various engineering fields, project management, and problem-solving."
    },
    {
      icon: <Settings className="w-12 h-12" />,
      title: "Proficiency in Industry-Standard Tools",
      description: "Proficiency in industry-standard tools such as Ansys, Abaqus, MSC Nastran NX, Matlab, and CATIA indicates a strong skill set in the field of engineering and simulation."
    }
  ];

  const keyFeatures = [
    {
      icon: <Zap className="w-12 h-12" />,
      title: "CFD Simulations",
      description: "Using CFD simulations we optimize performance and fluid dynamics in real-world applications."
    },
    {
      icon: <BarChart3 className="w-12 h-12" />,
      title: "Stress Analysis",
      description: "We offer comprehensive solutions for the design and analysis of mechanical/aerospace structures, ensuring the structural integrity of critical engineering components & assemblies."
    },
    {
      icon: <Code className="w-12 h-12" />,
      title: "Simulink",
      description: "Our services extend to the intricate fields of flight dynamics & control. We offer state of the art 6 DOF Simulations with flight controls modelling."
    }
  ];

  const tools = [
    { name: "Ansys", description: "Utilize the power of Ansys to perform advanced simulations and optimize engineering designs." },
    { name: "Abaqus", description: "Leverage Abaqus for realistic and reliable simulations to analyze and solve complex engineering problems." },
    { name: "MSC Nastran NX", description: "Tap into the capabilities of MSC Nastran NX to conduct high-fidelity finite element analysis and simulation." },
    { name: "CATIA", description: "Leverage the comprehensive design and engineering capabilities of CATIA for advanced product development." }
  ];

  const faqs = [
    {
      question: "NAQCORP in CFD Simulations?",
      answer: "Using CFD simulations we optimize performance and fluid dynamics in real-world applications."
    },
    {
      question: "NAQCORP in Stress Analysis?",
      answer: "We offer comprehensive solutions for the design and analysis of mechanical/aerospace structures, ensuring the structural integrity of critical engineering components & assemblies."
    },
    {
      question: "NAQCORP in Simulink?",
      answer: "Our services extend to the intricate fields of flight dynamics & control. We offer state of the art 6 DOF Simulations with flight controls modelling."
    },
    {
      question: "NAQCORP in Aeroelasticity?",
      answer: "Our experts specialize carrying out multi-physics simulation comprising of aerodynamic loads and structural response."
    },
    {
      question: "NAQCORP in Thermal Analysis?",
      answer: "Leveraging sophisticated tools and simulations, we conduct in-depth thermal analysis to understand heat distribution and devise efficient cooling strategies for your system."
    },
    {
      question: "NAQCORP in Aerodynamics Performance?",
      answer: "With our custom performance codes we utilize aerodynamic data for computation of platform performance charts."
    }
  ];

  const [openFaq, setOpenFaq] = React.useState<number | null>(null);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 bg-gradient-to-br from-orange-500 via-orange-600 to-orange-700 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/20 to-transparent animate-pulse" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-6">
            <h2 className="text-2xl md:text-3xl font-semibold text-white/90 animate-fade-in">
              CONSULTANCY & TECHNOLOGIES
            </h2>
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-white leading-tight">
              Welcome to <span className="text-orange-200">NAQCORP</span>
            </h1>
            <div className="space-y-4 max-w-4xl mx-auto">
              <p className="text-lg md:text-xl text-white/90">
                At NAQCORP, we are dedicated to providing top quality services and solutions to our clients.
              </p>
              <p className="text-lg md:text-xl text-white/90">
                With our expertise in various industries, we aim to deliver exceptional results and exceed expectations.
              </p>
              <p className="text-lg md:text-xl text-white/90">
                Join us on this journey towards success.
              </p>
            </div>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-8">
              <Link
                to="/technologies"
                className="group flex items-center space-x-2 bg-white text-orange-600 px-8 py-4 rounded-xl font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
              >
                <Settings className="w-5 h-5" />
                <span>Technologies</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
              
              <a
                href="#services"
                className="group flex items-center space-x-2 bg-orange-700 text-white px-8 py-4 rounded-xl font-semibold border-2 border-white/20 hover:bg-orange-800 transform hover:scale-105 transition-all duration-300"
              >
                <Lightbulb className="w-5 h-5" />
                <span>Explore Our Services</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>
              
              <Link
                to="/engineering-solutions"
                className="group flex items-center space-x-2 bg-transparent text-white px-8 py-4 rounded-xl font-semibold border-2 border-white/30 hover:bg-white/10 transform hover:scale-105 transition-all duration-300"
              >
                <Cog className="w-5 h-5" />
                <span>Engineering Solutions</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Info Strip */}
      <section className="bg-gray-50 dark:bg-gray-900 py-6 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row justify-center items-center gap-6 text-sm font-medium">
            <a 
              href="tel:+923215857205" 
              className="flex items-center space-x-2 text-gray-700 dark:text-gray-300 hover:text-orange-600 dark:hover:text-orange-400 transition-colors"
            >
              <Phone className="w-4 h-4" />
              <span>+92 321 585 7205</span>
            </a>
            <div className="hidden sm:block w-px h-4 bg-gray-300 dark:bg-gray-600" />
            <a 
              href="mailto:info@naqcorp.com" 
              className="flex items-center space-x-2 text-gray-700 dark:text-gray-300 hover:text-orange-600 dark:hover:text-orange-400 transition-colors"
            >
              <Mail className="w-4 h-4" />
              <span>info@naqcorp.com</span>
            </a>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
              You have a need, we have the <span className="text-orange-600">SOLUTION</span>
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div 
                key={index}
                className="group bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-lg hover:shadow-2xl transform hover:-translate-y-2 transition-all duration-300 border border-gray-100 dark:border-gray-700"
              >
                <div className="text-orange-600 mb-6 group-hover:scale-110 transition-transform duration-300">
                  {service.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4 group-hover:text-orange-600 transition-colors">
                  {service.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-4">
                  {service.description}
                </p>
                <button className="text-orange-600 hover:text-orange-700 font-medium text-sm group-hover:underline transition-colors">
                  Read More →
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Key Features Section */}
      <section className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Key Features</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {keyFeatures.map((feature, index) => (
              <div key={index} className="text-center group">
                <div className="text-orange-600 mb-6 mx-auto w-fit p-4 bg-orange-50 dark:bg-orange-900/20 rounded-2xl group-hover:scale-110 transition-transform duration-300">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">{feature.title}</h3>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose NAQCORP Section */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Why Choose NAQCORP</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {tools.map((tool, index) => (
              <div key={index} className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700 hover:shadow-xl transition-shadow duration-300">
                <div className="flex items-center mb-4">
                  <CheckCircle className="w-6 h-6 text-orange-600 mr-3" />
                  <h3 className="text-lg font-bold text-orange-600">{tool.name}</h3>
                </div>
                <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed">{tool.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Frequently Asked Questions</h2>
          </div>
          
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white dark:bg-gray-900 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700">
                <button
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                  className="w-full text-left p-6 flex justify-between items-center hover:bg-gray-50 dark:hover:bg-gray-800 rounded-2xl transition-colors"
                >
                  <span className="text-lg font-semibold text-gray-900 dark:text-white">{faq.question}</span>
                  <div className={`transform transition-transform duration-200 ${openFaq === index ? 'rotate-180' : ''}`}>
                    <svg className="w-5 h-5 text-gray-600 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </div>
                </button>
                {openFaq === index && (
                  <div className="px-6 pb-6">
                    <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;